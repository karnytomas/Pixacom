# React + Vite

Jednoduchá React aplikace pro správu příspěvků – vytvořená v rámci výuky.
Je tvořena 3 částmi:
    Seznam příspěvků
    Formulář pro vytvoření příspěvku
    Formulář pro úpravu příspěvku

Aplikace využívá API od MockAPI, CSS knihovnu Tailwind a ikonky z knihovny lucide-react.

Aplikace je nasazena na Vercel.
    Odkaz: 
